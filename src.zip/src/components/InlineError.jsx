import React from 'react';

export const InlineError = props => {
    return (
        <label class="">{props.message}</label>
    )
}