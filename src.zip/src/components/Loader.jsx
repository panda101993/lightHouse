import React from 'react';

const Loader = (props) =>{
    return(        
        <div className = "loader">
            {/* <img style ={{width:100, height:100}} className="" alt="" src={require("../assets/images/loader.gif")} /> */}
        </div>
        
    )
}

export default Loader;