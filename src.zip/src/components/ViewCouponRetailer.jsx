import React, { Component } from 'react'

export class ViewCouponRetailer extends Component {
    render() {
        return (
            <div>
                  <div class="basic mt-3 ">
               <div class="d-flex justify-content-between align-items-center">
                  <div class="john-json">
                     <h5>JOHN & JOHNSON</h5>
                     <h6>V-MART</h6>
                     <p>OKhala Phase 1,D-115, New Delhi </p> 
                     <p> shop Number,12352525</p>
                  </div>
                  <div> <a href="64-all-retailers.html"><button class="btn btn-theme">View Coupons</button></a></div>
               </div>
            </div>
            </div>
        )
    }
}

export default ViewCouponRetailer
