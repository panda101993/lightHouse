
export const JUST_ACTION="just_action";
export const FIRSTACTION="FIRSTACTION";
export const LOGIN_ACTION="LOGIN_ACTION";
export const SIGNUP_ACTION="SIGNUP_ACTION";
export const MyCoupon_Data="MyCoupon_Data";
export const RETAILER_PROFILE_ACTION="Retailer_profile_action";
export const LOGOUT_ACTION = "LOGOUT_ACTION";
export const ENDUSER_PROFILE_ACTION="ENDUSER_PROFILE_ACTION";

// FORM
export const APP_CREATOR_ACTION="APP_CREATOR_ACTION"