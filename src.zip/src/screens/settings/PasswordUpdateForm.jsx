import React, { Component } from 'react';

class PasswordUpdate extends Component {
    constructor(props){
        super(props);
        this.state={};
    }

    render(){
        return (
            <div >
               <h1>Update Password code should be here.</h1> 
            </div>
        )
    }
}

export default PasswordUpdate;