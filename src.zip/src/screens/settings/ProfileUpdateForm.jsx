import React, { Component } from 'react';

class ProfileUpdate extends Component {
    constructor(props){
        super(props);
        this.state={};
    }

    render(){
        return (
            <div>
               <h1>Update Profile code should be here.</h1> 
            </div>
        )
    }
}

export default ProfileUpdate;