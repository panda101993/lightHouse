import React, { Component } from 'react'
import Footer from '../../components/Footer'
import Header2 from '../../components/Header2'

export class CouponslistPopup extends Component {
    render() {
        return (
            <div> 
              <Header2 />   
              <section class="second">
         <div class="container-fluid">
            <div class="slidertop">
               <section class="center slider">
                  <div>
                     <div class="slicent activa">
                        Sub-Category Name
                     </div>
                  </div>
                  <div>
                     <div class="slicent">
                        Sub-Category Name
                     </div>
                  </div>
                  <div>
                     <div class="slicent">
                        Sub-Category Name
                     </div>
                  </div>
                  <div>
                     <div class="slicent">
                        Sub-Category Name
                     </div>
                  </div>
                  <div>
                     <div class="slicent">
                        Sub-Category Name
                     </div>
                  </div>
                  <div>
                     <div class="slicent">
                        Sub-Category Name
                     </div>
                  </div>
                  <div>
                     <div class="slicent">
                        Sub-Category Name
                     </div>
                  </div>
                  <div>
                     <div class="slicent">
                        Sub-Category Name
                     </div>
                  </div>
                  <div>
                     <div class="slicent">
                        Sub-Category Name
                     </div>
                  </div>
               </section>
            </div>
         </div>
      </section>
      <section class="third">
         <div class="container-fluid">
            <div class="row">
               <div class="col-md-3">
                  <div class="accor-bord">
                     <ul class="button_cs sve-can button-shift all-clr">
                        <li><button type="button" class="save0 s-1"data-toggle="modal" data-target="#this-coupon">Clear All</button></li>
                     </ul>
                     <div class="to-al-cent">
                        <div class="form-check first-nopad">
                           <div class="accordion" id="accordionExample">
                              <div class="car">
                                 <div class="card-heade">
                                    <h2 class="mb-0 down-arrow">
                                       <button class="btn btn-link blak-colr" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                       <input type="checkbox" class="form-check-input" id="exampleCheck1"/> <span class="mart-mar-left">Mart Name </span> 
                                       </button>
                                       <div>
                                          <i class="fa fa-caret-down" aria-hidden="true" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne"></i>
                                       </div>
                                    </h2>
                                 </div>
                                 <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                    <div class="card-body">
                                       <div class="form-group form-check no-pad-left">
                                          <div class="form-group form-check">
                                             <input type="checkbox" class="form-check-input" id="exampleCheck1"/>
                                             <label class="form-check-label" for="exampleCheck1">Retailer Name</label>
                                          </div>
                                          <div class="form-group form-check">
                                             <input type="checkbox" class="form-check-input" id="exampleCheck1"/>
                                             <label class="form-check-label" for="exampleCheck1">Retailer Name</label>
                                          </div>
                                          <div class="form-group form-check">
                                             <input type="checkbox" class="form-check-input" id="exampleCheck1"/>
                                             <label class="form-check-label" for="exampleCheck1">Retailer Name</label>
                                          </div>
                                          <div class="form-group form-check">
                                             <input type="checkbox" class="form-check-input" id="exampleCheck1"/>
                                             <label class="form-check-label" for="exampleCheck1">Retailer Name</label>
                                          </div>
                                          <div class="form-group form-check">
                                             <input type="checkbox" class="form-check-input" id="exampleCheck1"/>
                                             <label class="form-check-label" for="exampleCheck1">Retailer Name</label>
                                          </div>
                                          <div class="form-group form-check">
                                             <input type="checkbox" class="form-check-input" id="exampleCheck1"/>
                                             <label class="form-check-label" for="exampleCheck1">Retailer Name</label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="to-al-cent">
                        <div class="form-check first-nopad">
                           <div class="accordion" id="accordionExample">
                              <div class="car">
                                 <div class="card-heade" id="headingOne">
                                    <h2 class="mb-0 down-arrow">
                                       <button class="btn btn-link blak-colr" type="button" data-toggle="collapse" data-target="#collapseOn" aria-expanded="false" aria-controls="collapseOne">
                                       <input type="checkbox" class="form-check-input" id="exampleCheck1"/> <span class="mart-mar-left">Mart Name </span>
                                       </button>
                                       <div>
                                          <i class="fa fa-caret-down" aria-hidden="true" data-toggle="collapse" data-target="#collapseOn" aria-expanded="false" aria-controls="collapseOne"></i>
                                       </div>
                                    </h2>
                                 </div>
                                 <div id="collapseOn" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                    <div class="card-body">
                                       <div class="form-group form-check no-pad-left">
                                          <div class="form-group form-check">
                                             <input type="checkbox" class="form-check-input" id="exampleCheck1"/>
                                             <label class="form-check-label" for="exampleCheck1">Retailer Name</label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="to-al-cent">
                        <div class="form-check first-nopad">
                           <div class="accordion" id="accordionExample">
                              <div class="car">
                                 <div class="card-heade" id="headingOne">
                                    <h2 class="mb-0 down-arrow">
                                       <button class="btn btn-link blak-colr" type="button" data-toggle="collapse" data-target="#collapseO" aria-expanded="false" aria-controls="collapseOne">
                                       <input type="checkbox" class="form-check-input" id="exampleCheck1"/>  <span class="mart-mar-left">Mart Name </span>
                                       </button>
                                       <div>
                                          <i class="fa fa-caret-down" aria-hidden="true" data-toggle="collapse" data-target="#collapseO" aria-expanded="false" aria-controls="collapseOne"></i>
                                       </div>
                                    </h2>
                                 </div>
                                 <div id="collapseO" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                    <div class="card-body">
                                       <div class="form-group form-check no-pad-left">
                                          <div class="form-group form-check">
                                             <input type="checkbox" class="form-check-input" id="exampleCheck1"/>
                                             <label class="form-check-label" for="exampleCheck1">Retailer Name</label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="to-al-cent">
                        <div class="form-check first-nopad">
                           <div class="accordion" id="accordionExample">
                              <div class="car">
                                 <div class="card-heade" id="headingOne">
                                    <h2 class="mb-0 down-arrow">
                                       <button class="btn btn-link blak-colr" type="button" data-toggle="collapse" data-target="#collapse" aria-expanded="false" aria-controls="collapseOne">
                                       <input type="checkbox" class="form-check-input" id="exampleCheck1"/> <span class="mart-mar-left">Mart Name </span>
                                       </button>
                                       <div>
                                          <i class="fa fa-caret-down" aria-hidden="true" data-toggle="collapse" data-target="#collapse" aria-expanded="false" aria-controls="collapseOne"></i>
                                       </div>
                                    </h2>
                                 </div>
                                 <div id="collapse" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                    <div class="card-body">
                                       <div class="form-group form-check no-pad-left">
                                          <div class="form-group form-check">
                                             <input type="checkbox" class="form-check-input" id="exampleCheck1"/>
                                             <label class="form-check-label" for="exampleCheck1">Retailer Name</label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="to-al-cent">
                        <div class="form-check first-nopad">
                           <div class="accordion" id="accordionExample">
                              <div class="car">
                                 <div class="card-heade" id="headingOne">
                                    <h2 class="mb-0 down-arrow">
                                       <button class="btn btn-link blak-colr" type="button" data-toggle="collapse" data-target="#collap" aria-expanded="false" aria-controls="collapseOne">
                                       <input type="checkbox" class="form-check-input" id="exampleCheck1" />  
                                       <span class="mart-mar-left">Mart Name </span>
                                       </button>
                                       <div>
                                          <i class="fa fa-caret-down" aria-hidden="true" data-toggle="collapse" data-target="#collap" aria-expanded="false" aria-controls="collapseOne"></i>
                                       </div>
                                    </h2>
                                 </div>
                                 <div id="collap" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                    <div class="card-body">
                                       <div class="form-group form-check no-pad-left">
                                          <div class="form-group form-check">
                                             <input type="checkbox" class="form-check-input" id="exampleCheck1"/>
                                             <label class="form-check-label" for="exampleCheck1">Retailer Name</label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="to-al-cent">
                        <div class="form-check first-nopad">
                           <div class="accordion" id="accordionExample">
                              <div class="car">
                                 <div class="card-heade" id="headingOne">
                                    <h2 class="mb-0 down-arrow">
                                       <button class="btn btn-link blak-colr" type="button" data-toggle="collapse" data-target="#colla" aria-expanded="false" aria-controls="collapseOne">
                                       <input type="checkbox" class="form-check-input" id="exampleCheck1"/> <span class="mart-mar-left">Mart Name </span>
                                       </button>
                                       <div>
                                          <i class="fa fa-caret-down" aria-hidden="true" data-toggle="collapse" data-target="#colla" aria-expanded="false" aria-controls="collapseOne"></i>
                                       </div>
                                    </h2>
                                 </div>
                                 <div id="colla" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                    <div class="card-body">
                                       <div class="form-group form-check no-pad-left">
                                          <div class="form-group form-check">
                                             <input type="checkbox" class="form-check-input" id="exampleCheck1"/>
                                             <label class="form-check-label" for="exampleCheck1">Retailer Name</label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="to-al-cent">
                        <div class="form-check first-nopad">
                           <div class="accordion" id="accordionExample">
                              <div class="car">
                                 <div class="card-heade" id="headingOne">
                                    <h2 class="mb-0 down-arrow">
                                       <button class="btn btn-link blak-colr" type="button" data-toggle="collapse" data-target="#coll" aria-expanded="false" aria-controls="collapseOne">
                                       <input type="checkbox" class="form-check-input" id="exampleCheck1"/> <span class="mart-mar-left">Mart Name </span>
                                       </button>
                                       <div>
                                          <i class="fa fa-caret-down" aria-hidden="true" data-toggle="collapse" data-target="#coll" aria-expanded="false" aria-controls="collapseOne"></i>
                                       </div>
                                    </h2>
                                 </div>
                                 <div id="coll" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                    <div class="card-body">
                                       <div class="form-group form-check no-pad-left">
                                          <div class="form-group form-check ">
                                             <input type="checkbox" class="form-check-input" id="exampleCheck1"/>
                                             <label class="form-check-label" for="exampleCheck1">Retailer Name</label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-md-9">
                  <div class="slid-margin">
  
                  <div class="row mar-bottom">
                      <div class="col-md-3">
                      <img src="images/pizza great deal.png" class="pizza-deal" data-dismiss="modal" data-toggle="modal"
                       data-target="#great-deal"/>
                      </div>
                      <div class="col-md-3">
                      <img src="images/pizza great deal.png" class="pizza-deal"/>
                      </div>
                      <div class="col-md-3">
                      <img src="images/pizza great deal.png" class="pizza-deal"/>
                      </div>
                      <div class="col-md-3">
                      <img src="images/pizza great deal.png" class="pizza-deal"/>
                      </div>
                  </div>
  
                 
  
                  <div class="row mar-bottom">
                      <div class="col-md-3">
                      <img src="images/pizza great deal.png" class="pizza-deal"/>
                      </div>
                      <div class="col-md-3">
                      <img src="images/pizza great deal.png" class="pizza-deal"/>
                      </div>
                      <div class="col-md-3">
                      <img src="images/pizza great deal.png" class="pizza-deal"/>
                      </div>
                      <div class="col-md-3">
                      <img src="images/pizza great deal.png" class="pizza-deal" />
                      </div>
                  </div>
  
                </div>
               </div>
            </div>
         </div>
      </section>
            <Footer />  
            </div>
        )
    }
}

export default CouponslistPopup
